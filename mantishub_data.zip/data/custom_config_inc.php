<?php

/**
 * Whether the REST API (experimental) is enabled or not.  Note that this flag only
 * impacts API Token based auth.  Hence, even if the API is disabled, it can still be
 * used from the Web UI using cookie based authentication.
 *
 * @global integer $g_webservice_rest_enabled
 */
$g_webservice_rest_enabled = ON;
